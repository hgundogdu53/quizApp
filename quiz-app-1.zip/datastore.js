//BreakingBad question and answer data sore//
const STORE = [
{
question: "In what New Mexico city does 'Breaking Bad' take place?",
ans1: 'Santa Fe',
ans2: 'Albuquerque',
ans3: 'Las Cruces',
ans4: 'Roswell',

correctAnswer: 'Albuquerque',
},
{
question: 'Walt is a teacher of what high school subject?',
ans1: 'Chemistry',
ans2: 'Biology',
ans3: 'Physics',
ans4: 'Geology',

correctAnswer: 'Chemistry',
},
{
question: "What's the slogan of Saul Goodman's law firm?",
ans1: 'Turn Your Pain Into Rain.',
ans2: 'One Call…That’s All!',
ans3: 'Better Call Saul!',
ans4: 'Get What’s Yours.',

correctAnswer: 'Better Call Saul!',
},
{
question: "What weapons do Tuco's cousins use?",
ans1: 'Chainsaws',
ans2: 'Machetes',
ans3: 'Guns',
ans4: 'Axes',

correctAnswer: 'Axes',
},
{
question: "What's the name of the fried chicken restaurant owned by Gus Fring?",
ans1: 'Pollos Hermanos',
ans2: 'Pollo Feliz',
ans3: 'Delicioso Pollo',
ans4: 'Amigos de Pollo',

correctAnswer: 'Pollos Hermanos',
},
{
question: 'Which character does not end up dying by the end of the series?',
ans1: 'Uncle Jack',
ans2: 'Skinny Pete',
ans3: 'Walter White',
ans4: 'Hank',

correctAnswer: 'Skinny Pete',
},
{
question: 'Jesse Pinkman refers to himself as this in the first season:',
ans1: 'Master Chef',
ans2: 'Chef-Boyy-R-Dee',
ans3: 'Cap’n Cook',
ans4: 'Da Swedish Chef',

correctAnswer: 'Cap’n Cook',
},
{
question: 'What did Mike Ehrmantraut do for a living before he started working for Gus Fring?',
ans1: 'He was a lawyer',
ans2: 'He was a cop',
ans3: 'He was a prison guard',
ans4: 'He was a doctor',

correctAnswer: 'He was a cop',
},
{
question: 'What item does Hank find that makes him realize Walt is Heisenberg?',
ans1: 'His lab notes',
ans2: 'His bag filled with cash',
ans3: 'His blue meth',
ans4: 'His copy of “Leaves of Grass”',

correctAnswer: 'His copy of “Leaves of Grass”',
},
{
question: 'What does Walt poison Brock with in the season 4 episode“End Times"',
ans1: 'Ricin',
ans2: 'Lily of the Valley',
ans3: 'Nightshade',
ans4: 'Arsenic',

correctAnswer: 'Lily of the Valley',
}
];